
# THIS FILE IS GENERATED FROM SETUP.PY
version = '0.4.0'
isrelease = 'True'